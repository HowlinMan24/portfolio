# 01 · Monolith & Layered Architecture

**Complexity: Simple** · The sensible default for most new applications.

## What it is

A monolith is a single deployable unit that contains the entire application: UI rendering, business logic, and data access all ship and run together. The *layered* (or n-tier) style organises that single unit internally into horizontal layers, where each layer only talks to the one directly beneath it.

## Diagram

```mermaid
flowchart TD
  U[User] --> P[Presentation Layer<br/>controllers / views]
  P --> B[Business Layer<br/>services / domain rules]
  B --> D[Data Access Layer<br/>repositories / ORM]
  D --> DB[(Database)]
```

## How it works

A request enters at the presentation layer, flows down through business logic, and reaches the data layer, which is the only part that touches the database. Responses travel back up. Keeping the dependency direction strictly downward is what prevents a monolith from degrading into a tangle.

## When to use it

- New products and MVPs where requirements are still moving.
- Small teams that benefit from one codebase, one deploy, and simple local development.
- Any system where the operational cost of distributed components is not yet justified.

## When not to

- When different parts of the system need to scale independently.
- When multiple teams keep blocking each other in a single codebase and deploy pipeline.

## Trade-offs

**Pros:** simplest to build, test, and deploy; one place to debug; no network calls between components; lowest operational overhead.

**Cons:** scales as one block (you scale the whole thing even if only one feature is hot); a single deploy for every change; the codebase can grow hard to reason about without discipline.

## Real-world note

Most successful systems *start* here and only break pieces out later when a specific scaling or team-autonomy pain appears. "Monolith first" is a deliberate strategy, not a failure mode.
