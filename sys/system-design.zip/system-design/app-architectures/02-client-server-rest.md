# 02 · Client–Server REST API

**Complexity: Simple** · The standard shape of a modern web application.

## What it is

A clear split between a client (typically a single-page application) and a server that exposes a stateless HTTP API. The client owns rendering and user interaction; the server owns business logic, persistence, and security. They communicate over REST endpoints exchanging JSON.

## Diagram

```mermaid
flowchart LR
  SPA[SPA Client<br/>Angular / React] -->|HTTPS + JSON| API[REST API<br/>NestJS / Node]
  API --> Auth[Auth: JWT + RBAC]
  API --> DB[(Relational DB)]
  API --> Cache[(Redis cache)]
```

## How it works

The browser loads the SPA once, then makes API calls for data. The API authenticates each request with a token (e.g. a JWT), applies authorization rules, reads or writes the database, and returns JSON. Because the API holds no session state in memory, any instance can serve any request, which is what makes horizontal scaling straightforward.

## When to use it

- Almost any interactive web product with a rich front end.
- Cases where the same API must serve a web SPA and a mobile app.

## When not to

- Highly real-time, bidirectional workloads (live collaboration, trading tickers) where WebSockets or server-sent events fit better alongside, not instead of, REST.

## Trade-offs

**Pros:** clean separation of concerns; front and back ends evolve and deploy independently; stateless API scales horizontally; one backend can feed many clients.

**Cons:** two codebases to coordinate; over- and under-fetching are common REST pain points (a reason teams sometimes reach for GraphQL); careful API versioning is needed so client and server stay compatible.

## Real-world note

In a banking platform this is the backbone: an Angular front end for onboarding and dashboards, a stateless NestJS API enforcing JWT auth and role-based access on every compliance-sensitive call, with Redis caching the hot, read-heavy endpoints to keep response times low under load.
