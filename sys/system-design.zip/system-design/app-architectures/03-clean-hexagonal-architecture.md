# 03 · Clean / Hexagonal Architecture

**Complexity: Intermediate** · A way to structure a codebase so business rules outlive frameworks.

## What it is

Also called *ports and adapters*. The core idea: put domain logic at the centre, with no knowledge of databases, frameworks, or transport. Everything external (HTTP, the database, third-party APIs) plugs into the core through well-defined interfaces called *ports*, implemented by interchangeable *adapters*. Dependencies always point inward, toward the domain.

## Diagram

```mermaid
flowchart TD
  subgraph Outside[Adapters - replaceable]
    HTTP[HTTP Controller]
    REPO[DB Adapter]
    EXT[Payment Gateway Adapter]
  end
  subgraph Core[Application Core - stable]
    UC[Use Cases]
    DOM[Domain Model + Rules]
  end
  HTTP --> UC
  UC --> DOM
  UC -->|port| REPO
  UC -->|port| EXT
```

## How it works

A controller (adapter) calls a use case in the core. The use case orchestrates domain objects and talks to the outside world only through ports (interfaces). The concrete database or payment-provider adapter is injected at the edge. Swapping MySQL for Postgres, or one payment provider for another, means writing a new adapter; the domain never changes.

## When to use it

- Long-lived systems with complex business rules (finance, insurance, compliance).
- Codebases where you want the domain testable in isolation, with no database or framework spun up.

## When not to

- Simple CRUD apps, where the indirection adds ceremony without payoff.

## Trade-offs

**Pros:** business logic is framework-agnostic and easy to unit-test; external dependencies are swappable; clear boundaries slow down architectural rot.

**Cons:** more upfront structure and boilerplate; the layering can feel heavy for small features; requires team discipline to keep the dependency rule intact.

## Real-world note

This pattern pairs naturally with NestJS: controllers and database repositories are adapters, services hold use cases, and domain entities stay pure, so rules like KYC eligibility or transfer limits can be tested without a running database.
