# 04 · Microservices

**Complexity: Advanced** · Independently deployable services, one per business capability.

## What it is

The application is split into small, autonomous services, each owning a single business capability and its own data store. Services communicate over the network (synchronous HTTP/gRPC, or asynchronous messaging) and are deployed, scaled, and owned independently, often by different teams.

## Diagram

```mermaid
flowchart TD
  GW[API Gateway] --> A[Accounts Service]
  GW --> P[Payments Service]
  GW --> K[KYC Service]
  A --> ADB[(Accounts DB)]
  P --> PDB[(Payments DB)]
  K --> KDB[(KYC DB)]
  P -->|publishes event| BUS{{Message Bus}}
  BUS --> N[Notification Service]
```

## How it works

A gateway routes external requests to the right service. Each service is the single owner of its data (no shared database), which keeps services decoupled. Cross-service workflows are often handled asynchronously: the Payments service publishes an event, and interested services (notifications, ledger, fraud checks) react to it independently.

## When to use it

- Large systems with multiple teams that need to deploy without coordinating.
- Components with very different scaling or reliability profiles.

## When not to

- Early-stage products or small teams; the operational tax usually outweighs the benefits.
- When you cannot yet draw clean boundaries between capabilities.

## Trade-offs

**Pros:** independent deployment and scaling; fault isolation (one service failing need not take down the rest); teams own their services end to end; technology choices can vary per service.

**Cons:** significant operational complexity (networking, observability, deployment); distributed-system problems become your problem (latency, partial failure, eventual consistency); data that was one transaction is now spread across services.

## Real-world note

The hardest part is data consistency. A "transfer funds then send receipt" flow that was one database transaction in a monolith becomes a multi-service workflow, typically coordinated with the **saga pattern** (a sequence of local transactions with compensating actions if a step fails) rather than a distributed lock.
