# 05 · Event-Driven Architecture & CQRS

**Complexity: Advanced** · Components react to events; reads and writes are separated.

## What it is

Two related ideas that often appear together:

- **Event-driven architecture (EDA):** components communicate by emitting and reacting to events ("PaymentCompleted", "AccountFrozen") through a broker, instead of calling each other directly.
- **CQRS (Command Query Responsibility Segregation):** the write model (commands that change state) is separated from the read model (queries), so each can be optimised independently. Often paired with **event sourcing**, where state is stored as an append-only log of events rather than as current values.

## Diagram

```mermaid
flowchart LR
  C[Command<br/>e.g. SubmitTransfer] --> W[Write Model]
  W --> ES[(Event Store<br/>append-only log)]
  ES --> BUS{{Event Bus}}
  BUS --> RM[Read Model<br/>denormalised views]
  BUS --> AUD[Audit / Fraud]
  Q[Query] --> RM
```

## How it works

A command is validated by the write model, which appends events to an event store. Those events are published on a bus. Read models subscribe and build denormalised views optimised for queries; other consumers (audit, fraud detection, analytics) subscribe to the same stream. Current state can always be rebuilt by replaying events from the log.

## When to use it

- Domains needing a complete, immutable audit trail (finance, healthcare).
- Systems where read and write loads are very asymmetric and need separate scaling.
- Workflows with many independent reactions to a single business event.

## When not to

- Simple CRUD; the added complexity and eventual consistency are rarely worth it.

## Trade-offs

**Pros:** strong decoupling (publishers do not know subscribers); natural, complete audit log via event sourcing; reads and writes scale separately; easy to add new reactions without touching producers.

**Cons:** eventual consistency between write and read models; harder to reason about and debug across asynchronous flows; event-schema versioning becomes a long-term concern.

## Real-world note

A fintech ledger is a classic fit: every balance change is an event, the running balance is a projection you can rebuild at any time, and fraud-detection or notification services simply subscribe to the same event stream without the core payment path knowing they exist.
