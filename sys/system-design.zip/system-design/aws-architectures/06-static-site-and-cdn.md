# 06 · Static Site + CDN (AWS)

**Complexity: Simple** · Fast, cheap, highly available hosting for static front ends.

## What it is

Static assets (the built SPA, images, documents) are stored in an S3 bucket and served globally through the CloudFront CDN. There is no application server to run or patch; the content is just files, cached at edge locations close to users.

## Diagram

```mermaid
flowchart LR
  U[Users worldwide] --> CF[CloudFront CDN<br/>edge caching + TLS]
  CF --> S3[(S3 Bucket<br/>static assets)]
  CF --> ACM[ACM TLS Cert]
  R53[Route 53 DNS] --> CF
```

## How it works

Route 53 resolves the domain to CloudFront. CloudFront serves cached assets from the nearest edge location and only reaches back to S3 (the origin) on a cache miss. TLS is terminated at the edge with an ACM certificate. The S3 bucket itself is kept private and accessed only by CloudFront.

## When to use it

- SPAs, portfolios, documentation, marketing sites, any front end that builds to static files.
- The front-end tier of a larger app whose API lives elsewhere.

## When not to

- Anything requiring server-side rendering on every request or server-side secrets at the edge (though edge functions can cover lighter cases).

## Trade-offs

**Pros:** extremely cheap; effectively scales to any traffic level; low latency worldwide via edge caching; minimal operational surface and strong availability.

**Cons:** static only (dynamic behaviour must come from a separate API); cache invalidation on deploy needs handling; some routing nuances for SPAs (e.g. redirecting all paths to index.html).

## Real-world note

This is the right home for a deployed portfolio or a banking platform's front-end bundle: the Angular build lands in S3, CloudFront serves it globally with TLS, and the dynamic work happens behind a separate API tier.
