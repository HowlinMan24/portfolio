# 07 · Three-Tier Scalable Web App (AWS)

**Complexity: Intermediate** · Load-balanced compute with a managed, highly available database.

## What it is

The classic production web architecture on AWS: a front-end tier (CDN + static assets), an application tier of compute behind a load balancer that scales automatically, and a data tier using a managed relational database with a standby replica for failover. It spans multiple Availability Zones so the loss of one does not take the system down.

## Diagram

```mermaid
flowchart TD
  U[Users] --> CF[CloudFront]
  CF --> ALB[Application Load Balancer]
  subgraph AZ1[Availability Zone A]
    APP1[App instance]
  end
  subgraph AZ2[Availability Zone B]
    APP2[App instance]
  end
  ALB --> APP1
  ALB --> APP2
  APP1 --> CACHE[(ElastiCache / Redis)]
  APP2 --> CACHE
  APP1 --> RDS[(RDS Primary)]
  APP2 --> RDS
  RDS -. replication .-> RDSS[(RDS Standby)]
```

## How it works

The load balancer spreads traffic across application instances living in different Availability Zones. An auto-scaling group adds or removes instances based on load. A managed cache (ElastiCache) absorbs hot reads to protect the database. The primary RDS database synchronously replicates to a standby in another AZ; if the primary fails, AWS promotes the standby automatically.

## When to use it

- Production web apps and APIs needing reliable uptime and the ability to handle variable traffic.
- Teams that want resilience and scaling without managing servers and database failover by hand.

## When not to

- Tiny or bursty workloads where serverless (see 08) is cheaper and simpler.

## Trade-offs

**Pros:** horizontal scaling via auto-scaling; high availability across AZs; managed database removes backup/patch/failover toil; caching tier protects the data layer under load.

**Cons:** more moving parts and cost than a single server; you pay for baseline capacity even when idle; requires sound networking (VPC, subnets, security groups).

## Real-world note

For a banking platform this is the workhorse tier: stateless API instances behind an ALB scaling with demand, Redis caching high-traffic read endpoints, and a multi-AZ RDS instance so a zone outage causes a brief failover rather than downtime.
