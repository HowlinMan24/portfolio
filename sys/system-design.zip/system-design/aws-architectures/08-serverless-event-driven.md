# 08 · Serverless & Event-Driven (AWS)

**Complexity: Advanced** · Run code on demand with no servers to manage, glued together by events.

## What it is

Compute runs as short-lived functions (Lambda) triggered by events, fronted by API Gateway for HTTP, with a managed database (DynamoDB) and queues/topics (SQS, SNS, EventBridge) for asynchronous work. You provision no servers; you pay per request and per millisecond of execution.

## Diagram

```mermaid
flowchart TD
  U[Client] --> APIG[API Gateway]
  APIG --> L1[Lambda: handle request]
  L1 --> DDB[(DynamoDB)]
  L1 -->|publish| EB{{EventBridge / SNS}}
  EB --> Q[SQS Queue]
  Q --> L2[Lambda: async worker]
  L2 --> S3[(S3)]
  EB --> L3[Lambda: notifications]
```

## How it works

API Gateway receives an HTTP request and invokes a Lambda, which does the synchronous work and returns quickly. Anything slower or independent is pushed onto an event bus or queue and handled by separate worker Lambdas. Queues smooth out spikes and provide retries; functions scale automatically from zero to thousands of concurrent executions.

## When to use it

- Spiky, unpredictable, or low-baseline traffic where paying for idle servers is wasteful.
- Event processing, webhooks, scheduled jobs, and glue between services.

## When not to

- Steady high-throughput workloads (often cheaper on reserved compute).
- Latency-critical paths sensitive to cold starts, or long-running jobs that exceed function limits.

## Trade-offs

**Pros:** no servers to manage or patch; scales to zero (you pay nothing when idle) and up automatically; queues add resilience and natural retries; fast to ship small pieces.

**Cons:** cold-start latency; vendor lock-in to provider primitives; local testing and end-to-end debugging are harder; costs can surprise you at very high volume.

## Real-world note

The Kočani donation tool's screenshot-parsing flow maps cleanly onto this: an upload triggers a function that calls a vision model, the result is queued, and a worker aggregates donation totals asynchronously, with no always-on server needed for a short-lived, bursty workload.
