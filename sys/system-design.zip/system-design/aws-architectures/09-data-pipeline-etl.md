# 09 · Data Pipeline / ETL (AWS)

**Complexity: Advanced** · Ingest, transform, and serve data for analytics and ML at scale.

## What it is

A pipeline that moves data from many sources into a place where it can be analysed. Raw data lands in a data lake (S3), is transformed by distributed compute (Spark / Glue / EMR), and is loaded into a warehouse (Redshift) or served back to ML models. The pattern handles both scheduled batch loads and continuous streaming.

## Diagram

```mermaid
flowchart LR
  SRC[Sources<br/>apps, DBs, SAP] --> ING[Ingestion<br/>Kinesis / batch loads]
  ING --> RAW[(S3 - Raw Zone)]
  RAW --> ETL[Transform<br/>Glue / Spark / PySpark]
  ETL --> CUR[(S3 - Curated Zone)]
  CUR --> WH[(Redshift Warehouse)]
  CUR --> ML[ML Training / Models]
  WH --> BI[BI / Dashboards]
```

## How it works

Data is ingested continuously (Kinesis streams) or in scheduled batches and written untouched into a raw zone in S3, preserving the original. Distributed Spark/PySpark jobs clean, join, and reshape it into a curated zone. From there it feeds a warehouse for SQL analytics and dashboards, and the same curated data trains forecasting and classification models. Keeping raw and curated zones separate means transformations can be re-run or corrected without re-fetching source data.

## When to use it

- Combining multiple, messy data sources into a single analytical view.
- Powering BI dashboards, forecasting, and ML feature pipelines.

## When not to

- Small datasets that a single database query or script can handle; this machinery is overkill below a real scale threshold.

## Trade-offs

**Pros:** decouples ingestion, processing, and serving so each scales independently; the raw zone is a safety net (reprocess anytime); distributed compute handles datasets too big for one machine; one curated layer serves both analytics and ML.

**Cons:** many components to orchestrate and monitor; data quality and schema drift need active governance; batch pipelines introduce latency between event and insight.

## Real-world note

This is the backbone of the data work I do at Xient: PySpark ETL pipelines pulling complex multi-source data (including SAP and document-intelligence outputs) into a curated layer, which then drives revenue, churn, and demand forecasting models for enterprise clients.
